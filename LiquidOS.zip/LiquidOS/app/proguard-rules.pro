# LiquidOS launcher keeps default Android shrinker rules.
