package com.liquidos.launcher

import android.app.WallpaperManager
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class LaunchableApp(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LiquidLauncher() }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LiquidLauncher() {
    val context = LocalContext.current
    var apps by remember { mutableStateOf<List<LaunchableApp>>(emptyList()) }
    var page by remember { mutableIntStateOf(0) }
    var showLibrary by remember { mutableStateOf(false) }
    var showSearch by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var editMode by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var iconScale by remember { mutableFloatStateOf(1f) }
    var columns by remember { mutableIntStateOf(4) }
    var labels by remember { mutableStateOf(true) }
    var dark by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) {
            val pm = context.packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(intent, 0).mapNotNull {
                val info = it.activityInfo
                if (info.packageName == context.packageName) null
                else LaunchableApp(it.loadLabel(pm).toString(), info.packageName, it.loadIcon(pm))
            }.distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
        }
    }

    val background = if (dark) Color(0xFF111522) else Color(0xFFF0F2FA)
    val foreground = if (dark) Color.White else Color(0xFF1C2030)
    val pages = (apps.size.coerceAtLeast(1) + 23) / 24
    val pageApps = apps.drop(page * 24).take(24)

    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(background, if (dark) Color(0xFF252B43) else Color(0xFFDCE3F5))
                )
            ).pointerInput(editMode) {
                detectHorizontalDragGestures(onHorizontalDrag = { _, amount ->
                    if (!showLibrary && !showSearch && !showSettings && !editMode) {
                        if (amount < -18) page = (page + 1).coerceAtMost(pages - 1)
                        if (amount > 18) page = (page - 1).coerceAtLeast(0)
                    }
                })
            }
        ) {
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 22.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("LiquidOS", color = foreground.copy(alpha = .72f), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(onClick = { showSearch = true }) { Icon(Icons.Default.Search, "Search", tint = foreground) }
                        IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Settings", tint = foreground) }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    WidgetTile("09:41", "Clock", Modifier.weight(1f), foreground)
                    WidgetTile("Today", "Calendar", Modifier.weight(1f), foreground)
                }
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(if (editMode) "Edit Home Screen" else "Home", color = foreground, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(if (editMode) "Done" else "Edit", color = Color(0xFF9EACFF), modifier = Modifier.clickable { editMode = !editMode }.padding(8.dp))
                }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(columns),
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(top = 8.dp, bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(pageApps, key = { it.packageName }) { app ->
                        AppIcon(app, iconScale, labels, foreground, editMode) {
                            val launch = context.packageManager.getLaunchIntentForPackage(app.packageName)
                            if (launch != null) context.startActivity(launch)
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    repeat(pages) { index ->
                        Box(Modifier.padding(4.dp).size(if (page == index) 8.dp else 6.dp).clip(RoundedCornerShape(50)).background(if (page == index) foreground else foreground.copy(alpha = .35f)).clickable { page = index })
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                        .background(Color.White.copy(alpha = if (dark) .15f else .48f))
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    DockAction("Phone", "☎", foreground) { apps.firstOrNull { it.label.contains("phone", true) }?.let { context.startActivity(context.packageManager.getLaunchIntentForPackage(it.packageName)) } }
                    DockAction("Library", "▦", foreground) { showLibrary = true }
                    DockAction("Search", "⌕", foreground) { showSearch = true }
                    DockAction("Widgets", "◫", foreground) { showSettings = true }
                }
                Spacer(Modifier.height(10.dp))
                Text("Swipe horizontally to change pages · Long-press Edit to customize", color = foreground.copy(alpha = .55f), fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            }

            if (showLibrary) LibrarySheet(apps, foreground, { showLibrary = false }, { app ->
                context.packageManager.getLaunchIntentForPackage(app.packageName)?.let(context::startActivity)
            })
            if (showSearch) SearchOverlay(apps, foreground, query, { query = it }, { showSearch = false }, { app ->
                context.packageManager.getLaunchIntentForPackage(app.packageName)?.let(context::startActivity)
                showSearch = false
            })
            if (showSettings) SettingsPanel(
                foreground, columns, { columns = it }, iconScale, { iconScale = it },
                labels, { labels = it }, dark, { dark = it },
                { showSettings = false }, { editMode = true; showSettings = false }
            )
        }
    }
}

@Composable
private fun WidgetTile(value: String, label: String, modifier: Modifier, foreground: Color) {
    Column(modifier.clip(RoundedCornerShape(24.dp)).background(Color.White.copy(alpha = .14f)).padding(16.dp)) {
        Text(value, color = foreground, fontSize = 26.sp, fontWeight = FontWeight.Light)
        Text(label, color = foreground.copy(alpha = .65f), fontSize = 12.sp)
    }
}

@Composable
private fun AppIcon(app: LaunchableApp, scale: Float, labels: Boolean, foreground: Color, edit: Boolean, onClick: () -> Unit) {
    val icon = remember(app.packageName) { app.icon }
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick).padding(2.dp)) {
        Box(
            Modifier.size((54 * scale).dp).clip(RoundedCornerShape(18.dp))
                .background(Color.White.copy(alpha = .12f)),
            contentAlignment = Alignment.Center
        ) {
            androidx.compose.foundation.Image(
                painter = rememberDrawablePainterCompat(icon),
                contentDescription = app.label,
                modifier = Modifier.fillMaxSize().padding(2.dp)
            )
            if (edit) Text("−", color = Color.White, modifier = Modifier.align(Alignment.TopEnd).background(Color.Red, RoundedCornerShape(50)).padding(horizontal = 4.dp), fontSize = 11.sp)
        }
        if (labels) Text(app.label, color = foreground, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
private fun rememberDrawablePainterCompat(drawable: android.graphics.drawable.Drawable): androidx.compose.ui.graphics.painter.Painter {
    val bitmap = remember(drawable) {
        val width = drawable.intrinsicWidth.coerceAtLeast(1).coerceAtMost(192)
        val height = drawable.intrinsicHeight.coerceAtLeast(1).coerceAtMost(192)
        val bmp = android.graphics.Bitmap.createBitmap(width, height, android.graphics.Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bmp)
        drawable.setBounds(0, 0, width, height)
        drawable.draw(canvas)
        bmp.asImageBitmap()
    }
    return androidx.compose.ui.graphics.painter.BitmapPainter(bitmap)
}

@Composable
private fun DockAction(label: String, glyph: String, foreground: Color, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick).padding(horizontal = 6.dp, vertical = 4.dp)) {
        Text(glyph, color = foreground, fontSize = 25.sp)
        Text(label, color = foreground.copy(alpha = .72f), fontSize = 9.sp)
    }
}

@Composable
private fun LibrarySheet(apps: List<LaunchableApp>, foreground: Color, close: () -> Unit, launch: (LaunchableApp) -> Unit) {
    var search by remember { mutableStateOf("") }
    var alphabetical by remember { mutableStateOf(false) }
    Dialog(onDismissRequest = close, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(Color(0xF0181D2D)).padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("App Library", color = foreground, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Close", color = Color(0xFFAAB7FF), modifier = Modifier.clickable { close() }.padding(8.dp))
            }
            BasicTextField(search, { search = it }, Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = .12f)).padding(14.dp), textStyle = androidx.compose.ui.text.TextStyle(color = foreground), decorationBox = { inner -> if (search.isEmpty()) Text("Search apps", color = foreground.copy(alpha = .5f)); inner() })
            Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.End) {
                Text(if (alphabetical) "Show categories" else "A–Z list", color = Color(0xFFAAB7FF), modifier = Modifier.clickable { alphabetical = !alphabetical })
            }
            val filtered = apps.filter { it.label.contains(search, true) }.let { if (alphabetical) it.sortedBy { a -> a.label.lowercase() } else it }
            LazyVerticalGrid(columns = GridCells.Fixed(4), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                items(filtered, key = { it.packageName }) { app -> AppIcon(app, .9f, true, foreground, false) { launch(app) } }
            }
        }
    }
}

@Composable
private fun SearchOverlay(apps: List<LaunchableApp>, foreground: Color, query: String, onQuery: (String) -> Unit, close: () -> Unit, launch: (LaunchableApp) -> Unit) {
    Dialog(onDismissRequest = close, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(Color(0xE9101422)).padding(22.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Search, null, tint = foreground)
                Spacer(Modifier.width(10.dp))
                BasicTextField(query, onQuery, Modifier.weight(1f), textStyle = androidx.compose.ui.text.TextStyle(color = foreground, fontSize = 19.sp), decorationBox = { inner -> if (query.isEmpty()) Text("Search", color = foreground.copy(alpha = .55f), fontSize = 19.sp); inner() })
                Text("Cancel", color = Color(0xFFAAB7FF), modifier = Modifier.clickable { close() }.padding(8.dp))
            }
            Spacer(Modifier.height(18.dp))
            val matches = apps.filter { it.label.contains(query, true) || it.packageName.contains(query, true) }.take(30)
            LazyVerticalGrid(columns = GridCells.Fixed(4), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(matches, key = { it.packageName }) { app -> AppIcon(app, .9f, true, foreground, false) { launch(app) } }
            }
            Spacer(Modifier.weight(1f))
            Text("Search installed apps", color = foreground.copy(alpha = .5f), fontSize = 12.sp)
        }
    }
}

@Composable
private fun SettingsPanel(
    foreground: Color, columns: Int, setColumns: (Int) -> Unit, scale: Float, setScale: (Float) -> Unit,
    labels: Boolean, setLabels: (Boolean) -> Unit, dark: Boolean, setDark: (Boolean) -> Unit,
    close: () -> Unit, edit: () -> Unit
) {
    val context = LocalContext.current
    Dialog(onDismissRequest = close, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(Color(0xFF171C2B)).padding(22.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Settings", color = foreground, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text("Done", color = Color(0xFFAAB7FF), modifier = Modifier.clickable { close() }.padding(8.dp))
            }
            Spacer(Modifier.height(20.dp))
            Text("APPEARANCE", color = Color(0xFFAAB7FF), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text("Home screen columns: $columns", color = foreground)
            Slider(value = columns.toFloat(), onValueChange = { setColumns(it.toInt().coerceIn(3, 6)) }, valueRange = 3f..6f, steps = 2)
            Text("Icon size: ${(scale * 100).toInt()}%", color = foreground)
            Slider(value = scale, onValueChange = setScale, valueRange = .75f..1.3f)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("App labels", color = foreground)
                Switch(checked = labels, onCheckedChange = setLabels)
            }
            Divider(color = foreground.copy(alpha = .15f))
            Text("THEME", color = Color(0xFFAAB7FF), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Dark appearance", color = foreground)
                Switch(checked = dark, onCheckedChange = setDark)
            }
            Divider(color = foreground.copy(alpha = .15f))
            Text("HOME SCREEN", color = Color(0xFFAAB7FF), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text("Edit home screen", color = foreground, modifier = Modifier.clickable { edit() }.padding(vertical = 14.dp))
            Text("Change wallpaper", color = foreground, modifier = Modifier.clickable {
                runCatching { context.startActivity(Intent(Intent.ACTION_SET_WALLPAPER)) }
            }.padding(vertical = 14.dp))
            Spacer(Modifier.weight(1f))
            Text("LiquidOS 1.0 · Android launcher", color = foreground.copy(alpha = .45f), fontSize = 11.sp)
        }
    }
}
