# LiquidOS

A Kotlin + Jetpack Compose Android HOME launcher starter with app discovery, paged home screen, dock, app library, app search, basic appearance settings, and a translucent visual style.

## Build
Open the `LiquidOS` directory in CodeAssist, allow Gradle sync, then run the `app` configuration on an Android 8.0+ device. Select LiquidOS as the Home app when Android prompts.

## Scope notes
Android's launcher role does not grant control over Samsung's status bar, notification shade, or lock screen. This project intentionally leaves those system surfaces untouched. The current implementation provides a functional launcher foundation; advanced features such as persistent drag-and-drop layouts, real weather/music widgets, icon-pack parsing, tilt parallax, JSON backup/restore, and full system-wide fuzzy/settings search are not implemented in this starter.
