package com.liquidos.launcher

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.graphics.RenderEffect as AndroidRenderEffect
import android.graphics.Shader
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

data class LaunchableApp(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable)

private class SuperellipseShape(private val exponent: Float = 4.6f) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: androidx.compose.ui.unit.Density): Outline {
        val path = Path()
        for (i in 0..96) {
            val t = 2.0 * Math.PI * i / 96
            val c = cos(t); val s = sin(t)
            val nx = (if (c < 0) -1.0 else 1.0) * abs(c).pow(2.0 / exponent.toDouble())
            val ny = (if (s < 0) -1.0 else 1.0) * abs(s).pow(2.0 / exponent.toDouble())
            val x = size.width / 2f + size.width / 2f * nx.toFloat()
            val y = size.height / 2f + size.height / 2f * ny.toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        return Outline.Generic(path)
    }
}
private val Squircle = SuperellipseShape()

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // No system-bar flags are changed; Samsung retains ownership of system UI.
        setContent { LiquidLauncher() }
    }
}

@Composable
fun LiquidLauncher() {
    val context = LocalContext.current
    var apps by remember { mutableStateOf<List<LaunchableApp>>(emptyList()) }
    var page by remember { mutableIntStateOf(0) }
    var library by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var scale by remember { mutableFloatStateOf(1f) }
    var columns by remember { mutableIntStateOf(4) }
    var labels by remember { mutableStateOf(true) }
    var dark by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) {
            val pm = context.packageManager
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .mapNotNull { r ->
                    val a = r.activityInfo ?: return@mapNotNull null
                    if (a.packageName == context.packageName) null
                    else LaunchableApp(r.loadLabel(pm).toString(), a.packageName, r.loadIcon(pm))
                }.distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
        }
    }

    val ink = Color.White
    val wallpaper = Brush.linearGradient(listOf(Color(0xFF092D62), Color(0xFF6743B8), Color(0xFFE65D9E), Color(0xFFFFB36B)))
    val pageCount = ((apps.size + 23) / 24).coerceAtLeast(1)
    Box(Modifier.fillMaxSize().background(wallpaper).pointerInput(library, search, settings) {
        detectHorizontalDragGestures { _, delta ->
            if (!library && !search && !settings) {
                if (delta < -22) page = (page + 1).coerceAtMost(pageCount - 1)
                if (delta > 22) page = (page - 1).coerceAtLeast(0)
            }
        }
    }) {
        Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0x66FFFFFF), Color.Transparent), radius = 950f)))
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 18.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("LiquidOS", color = ink, fontSize = 15.sp, fontWeight = FontWeight.Light, letterSpacing = 1.2.sp)
                Row {
                    IconButton(onClick = { search = true }) { Icon(Icons.Default.Search, "Search", tint = ink) }
                    IconButton(onClick = { settings = true }) { Icon(Icons.Default.Settings, "Settings", tint = ink) }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                GlassPanel(Modifier.weight(1f).height(92.dp), true) {
                    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
                        Text("09:41", color = ink, fontSize = 30.sp, fontWeight = FontWeight.ExtraLight)
                        Text("THURSDAY · NOVEMBER 12", color = ink.copy(.75f), fontSize = 9.sp, letterSpacing = 1.sp)
                    }
                }
                GlassPanel(Modifier.weight(1f).height(92.dp), true) {
                    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
                        Text("Today", color = ink, fontSize = 22.sp, fontWeight = FontWeight.Light)
                        Text("Your day at a glance", color = ink.copy(.75f), fontSize = 10.sp)
                    }
                }
            }
            LazyVerticalGrid(
                columns = GridCells.Fixed(columns), modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(vertical = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                items(apps.drop(page * 24).take(24), key = { it.packageName }) { app ->
                    AppIcon(app, scale, labels, ink) {
                        context.packageManager.getLaunchIntentForPackage(app.packageName)?.let(context::startActivity)
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                repeat(pageCount) { i ->
                    Box(Modifier.padding(4.dp).size(if (page == i) 7.dp else 5.dp).clip(CircleShape)
                        .background(if (page == i) Color.White else Color.White.copy(.45f)).clickable { page = i })
                }
            }
            Spacer(Modifier.height(12.dp))
            GlassPanel(Modifier.fillMaxWidth().height(76.dp), true, 18f, RoundedCornerShape(28.dp)) {
                Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    DockItem("Phone", "☎", ink) {
                        apps.firstOrNull { it.label.contains("phone", true) }?.let { a ->
                            context.packageManager.getLaunchIntentForPackage(a.packageName)?.let(context::startActivity)
                        }
                    }
                    DockItem("Library", "▦", ink) { library = true }
                    DockItem("Search", "⌕", ink) { search = true }
                    DockItem("Settings", "⚙", ink) { settings = true }
                }
            }
        }
        if (library) AppOverlay("App Library", apps, ink, { library = false }, { query }, { query = it }, { a ->
            context.packageManager.getLaunchIntentForPackage(a.packageName)?.let(context::startActivity)
        })
        if (search) AppOverlay("Spotlight Search", apps, ink, { search = false }, { query }, { query = it }, { a ->
            context.packageManager.getLaunchIntentForPackage(a.packageName)?.let(context::startActivity); search = false
        })
        if (settings) SettingsOverlay(ink, columns, { columns = it }, scale, { scale = it }, labels, { labels = it }, dark, { dark = it }, { settings = false })
    }
}

/** API 31+ applies Android RenderEffect to the glass backing layer; API 26-30 uses translucent layered glass. */
@Composable
private fun GlassPanel(
    modifier: Modifier, dark: Boolean, blurRadius: Float = 14f,
    shape: Shape = Squircle, content: @Composable BoxScope.() -> Unit
) {
    val tint = if (dark) Color(0x36FFFFFF) else Color(0x55FFFFFF)
    Box(modifier.clip(shape).border(1.dp, Brush.linearGradient(listOf(Color(0xDFFFFFFF), Color(0x24FFFFFF), Color(0x12FFFFFF))), shape)) {
        Box(Modifier.matchParentSize().background(Brush.linearGradient(listOf(Color(0x77FFFFFF), Color(0x18FFFFFF), Color(0x38A9C8FF))))
            .graphicsLayer {
                if (Build.VERSION.SDK_INT >= 31) {
                    renderEffect = AndroidRenderEffect.createBlurEffect(blurRadius, blurRadius, Shader.TileMode.CLAMP).asComposeRenderEffect()
                }
            })
        Box(Modifier.matchParentSize().background(tint))
        Box(Modifier.matchParentSize().background(Brush.linearGradient(listOf(Color(0x38FFFFFF), Color.Transparent, Color(0x12FFFFFF)))))
        content()
    }
}

@Composable
private fun AppIcon(app: LaunchableApp, scale: Float, labels: Boolean, ink: Color, onClick: () -> Unit) {
    val bitmap = remember(app.packageName) {
        val d = app.icon
        val w = d.intrinsicWidth.coerceAtLeast(1).coerceAtMost(192)
        val h = d.intrinsicHeight.coerceAtLeast(1).coerceAtMost(192)
        android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888).also { b ->
            val c = android.graphics.Canvas(b); d.setBounds(0, 0, w, h); d.draw(c)
        }.asImageBitmap()
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick)) {
        Box(Modifier.size((58f * scale).dp).clip(Squircle).background(Color.White.copy(.16f))
            .border(.8.dp, Brush.linearGradient(listOf(Color.White.copy(.9f), Color.White.copy(.08f), Color.Transparent)), Squircle)) {
            Image(bitmap, app.label, Modifier.fillMaxSize().clip(Squircle).padding(1.dp))
        }
        if (labels) Text(app.label, color = ink, fontSize = 10.sp, maxLines = 1, fontWeight = FontWeight.Light, fontFamily = FontFamily.SansSerif)
    }
}

@Composable
private fun DockItem(label: String, glyph: String, ink: Color, click: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = click).padding(horizontal = 8.dp, vertical = 5.dp)) {
        Text(glyph, color = ink, fontSize = 27.sp, fontWeight = FontWeight.Light)
        Text(label, color = ink.copy(.76f), fontSize = 9.sp, fontWeight = FontWeight.Light)
    }
}

@Composable
private fun AppOverlay(
    title: String, apps: List<LaunchableApp>, ink: Color, close: () -> Unit,
    query: () -> String, setQuery: (String) -> Unit, launch: (LaunchableApp) -> Unit
) {
    Dialog(onDismissRequest = close, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color(0xA9001028))) {
            GlassPanel(Modifier.fillMaxSize(), true, 24f, RoundedCornerShape(0.dp)) {
                Column(Modifier.fillMaxSize().padding(20.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(title, color = ink, fontSize = 27.sp, fontWeight = FontWeight.Light)
                        Text("Done", color = Color.White, modifier = Modifier.clickable { close() }.padding(8.dp))
                    }
                    BasicTextField(query(), setQuery, Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                        .background(Color.White.copy(.16f)).padding(14.dp),
                        textStyle = TextStyle(color = ink, fontSize = 17.sp, fontWeight = FontWeight.Light),
                        decorationBox = { inner -> if (query().isEmpty()) Text("Search apps", color = ink.copy(.6f)); inner() })
                    Spacer(Modifier.height(16.dp))
                    val found = apps.filter { it.label.contains(query(), true) || it.packageName.contains(query(), true) }
                    LazyVerticalGrid(columns = GridCells.Fixed(4), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        items(found, key = { it.packageName }) { app -> AppIcon(app, .9f, true, ink) { launch(app) } }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsOverlay(
    ink: Color, columns: Int, setColumns: (Int) -> Unit, scale: Float, setScale: (Float) -> Unit,
    labels: Boolean, setLabels: (Boolean) -> Unit, dark: Boolean, setDark: (Boolean) -> Unit, close: () -> Unit
) {
    Dialog(onDismissRequest = close, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF172D58), Color(0xFF513A78), Color(0xFF8E477B)))).padding(22.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Settings", color = ink, fontSize = 28.sp, fontWeight = FontWeight.Light)
                Text("Done", color = Color.White, modifier = Modifier.clickable { close() }.padding(8.dp))
            }
            Spacer(Modifier.height(22.dp))
            GlassPanel(Modifier.fillMaxWidth(), true) {
                Column(Modifier.padding(16.dp)) {
                    Text("HOME SCREEN", color = Color.White.copy(.75f), fontSize = 11.sp, letterSpacing = 1.4.sp)
                    Text("Columns: $columns", color = ink)
                    Slider(columns.toFloat(), { setColumns(it.toInt().coerceIn(3, 6)) }, valueRange = 3f..6f, steps = 2)
                    Text("Icon size: ${(scale * 100).toInt()}%", color = ink)
                    Slider(scale, setScale, valueRange = .75f..1.3f)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("App labels", color = ink); Switch(labels, setLabels)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            GlassPanel(Modifier.fillMaxWidth(), true) {
                Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Dark appearance", color = ink); Switch(dark, setDark)
                }
            }
            Spacer(Modifier.weight(1f))
            Text("LiquidOS · Liquid Glass interface", color = Color.White.copy(.65f), fontSize = 11.sp)
        }
    }
}
